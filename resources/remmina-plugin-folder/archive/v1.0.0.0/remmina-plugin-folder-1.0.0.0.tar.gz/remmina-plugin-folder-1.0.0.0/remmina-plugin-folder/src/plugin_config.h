#ifndef __PLUGIN_CONFIG_H
#define __PLUGIN_CONFIG_H

#define PLUGIN_NAME        "FOLDER"
#define PLUGIN_DESCRIPTION "FOLDER - Open a folder"
#define PLUGIN_VERSION     "1.0.0.0"
#define PLUGIN_APPICON     "remmina-folder"
#endif
