#!/bin/bash
msginit --input=gextractwinicons.pot --output-file=en_US.po --locale=en_US
msginit --input=gextractwinicons.pot --output-file=it.po --locale=it_IT
msginit --input=gextractwinicons.pot --output-file=fr.po --locale=fr_FR
read
msginit --input=gextractwinicons.pot --output-file=es.po --locale=es_ES
msginit --input=gextractwinicons.pot --output-file=ru.po --locale=ru_RU
msginit --input=gextractwinicons.pot --output-file=ar.po --locale=ar
msginit --input=gextractwinicons.pot --output-file=bg.po --locale=bg
msginit --input=gextractwinicons.pot --output-file=cs.po --locale=cs
msginit --input=gextractwinicons.pot --output-file=da.po --locale=da
msginit --input=gextractwinicons.pot --output-file=de.po --locale=de_DE
msginit --input=gextractwinicons.pot --output-file=he.po --locale=he
msginit --input=gextractwinicons.pot --output-file=hu.po --locale=hu
msginit --input=gextractwinicons.pot --output-file=ja.po --locale=ja
msginit --input=gextractwinicons.pot --output-file=nl.po --locale=nl_NL
msginit --input=gextractwinicons.pot --output-file=pl.po --locale=pl
msginit --input=gextractwinicons.pot --output-file=pt.po --locale=pt_PT
msginit --input=gextractwinicons.pot --output-file=sk.po --locale=sk
msginit --input=gextractwinicons.pot --output-file=tr.po --locale=tr
msginit --input=gextractwinicons.pot --output-file=zh_CN.po --locale=zh_CN
read
