#ifndef __PLUGIN_CONFIG_H
#define __PLUGIN_CONFIG_H

#define PLUGIN_NAME        "WEBKIT"
#define PLUGIN_DESCRIPTION "WEBKIT - Launch a GTK+ Webkit browser"
#define PLUGIN_VERSION     "1.0.0.1"
#define PLUGIN_APPICON     "remmina-webkit"
#endif
