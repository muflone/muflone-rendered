#ifndef __PLUGIN_CONFIG_H
#define __PLUGIN_CONFIG_H

#define PLUGIN_NAME        "ULTRAVNC"
#define PLUGIN_DESCRIPTION "ULTRAVNC - Open a VNC connection with UltraVNC viewer"
#define PLUGIN_VERSION     "1.0.0.1"
#define PLUGIN_APPICON     "remmina-ultravnc"
#endif
