#!/bin/bash
msginit --input=gwakeonlan.pot --output-file=en_US.po --locale=en_US
msginit --input=gwakeonlan.pot --output-file=it.po --locale=it_IT
msginit --input=gwakeonlan.pot --output-file=fr.po --locale=fr_FR
msginit --input=gwakeonlan.pot --output-file=es.po --locale=es_ES

