#ifndef __PLUGIN_CONFIG_H
#define __PLUGIN_CONFIG_H

#define PLUGIN_NAME        "URL"
#define PLUGIN_DESCRIPTION "URL - Open an URL in an external browser"
#define PLUGIN_VERSION     "1.0.0.0"
#define PLUGIN_APPICON     "remmina-url"
#endif
