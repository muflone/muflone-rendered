#ifndef __PLUGIN_CONFIG_H
#define __PLUGIN_CONFIG_H

#define PLUGIN_NAME        "RDESKTOP"
#define PLUGIN_DESCRIPTION "RDESKTOP - Open a RDP connection with rdesktop"
#define PLUGIN_VERSION     "1.0.0.0"
#define PLUGIN_APPICON     "remmina-rdesktop"
#endif
