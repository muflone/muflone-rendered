#ifndef __PLUGIN_CONFIG_H
#define __PLUGIN_CONFIG_H

#define PLUGIN_NAME        "OPEN"
#define PLUGIN_DESCRIPTION "OPEN - Open a document with its application"
#define PLUGIN_VERSION     "1.0.0.1"
#define PLUGIN_APPICON     "remmina-open"
#endif
