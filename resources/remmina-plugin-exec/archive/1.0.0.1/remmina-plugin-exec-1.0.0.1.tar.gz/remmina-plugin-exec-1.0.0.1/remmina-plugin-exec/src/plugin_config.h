#ifndef __PLUGIN_CONFIG_H
#define __PLUGIN_CONFIG_H

#define PLUGIN_NAME        "EXEC"
#define PLUGIN_DESCRIPTION "EXEC - Execute an external process"
#define PLUGIN_VERSION     "1.0.0.1"
#define PLUGIN_APPICON     "remmina-exec"
#endif
