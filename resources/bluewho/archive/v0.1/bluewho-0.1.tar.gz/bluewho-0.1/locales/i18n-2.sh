#!/bin/bash
msginit --input=bluewho.pot --output-file=en_US.po --locale=en_US
msginit --input=bluewho.pot --output-file=it.po --locale=it_IT
msginit --input=bluewho.pot --output-file=fr.po --locale=fr_FR
read
msginit --input=bluewho.pot --output-file=es.po --locale=es_ES
msginit --input=bluewho.pot --output-file=ru.po --locale=ru_RU
msginit --input=bluewho.pot --output-file=ar.po --locale=ar
msginit --input=bluewho.pot --output-file=bg.po --locale=bg
msginit --input=bluewho.pot --output-file=cs.po --locale=cs
msginit --input=bluewho.pot --output-file=da.po --locale=da
msginit --input=bluewho.pot --output-file=de.po --locale=de_DE
msginit --input=bluewho.pot --output-file=he.po --locale=he
msginit --input=bluewho.pot --output-file=hu.po --locale=hu
msginit --input=bluewho.pot --output-file=ja.po --locale=ja
msginit --input=bluewho.pot --output-file=nl.po --locale=nl_NL
msginit --input=bluewho.pot --output-file=pl.po --locale=pl
msginit --input=bluewho.pot --output-file=pt.po --locale=pt_PT
msginit --input=bluewho.pot --output-file=sk.po --locale=sk
msginit --input=bluewho.pot --output-file=tr.po --locale=tr
msginit --input=bluewho.pot --output-file=zh_CN.po --locale=zh_CN
read
